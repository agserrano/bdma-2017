package bdma.labos.hadoop.reader;

public class MyHBaseReader_C_1 extends MyHBaseReader {

	protected String[] scanFamilies() {
		return null;
	}
		
}
