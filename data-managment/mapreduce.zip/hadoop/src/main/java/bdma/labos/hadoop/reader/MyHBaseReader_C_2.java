package bdma.labos.hadoop.reader;

public class MyHBaseReader_C_2 extends MyHBaseReader {

	protected String scanStart() {
		return null;
	}
	
	protected String scanStop() {
		return null;
	}
		
}
