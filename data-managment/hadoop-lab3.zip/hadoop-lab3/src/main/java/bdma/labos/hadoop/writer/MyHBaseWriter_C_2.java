package bdma.labos.hadoop.writer;

public class MyHBaseWriter_C_2 extends MyHBaseWriter {

	protected String nextKey() {
		return null;
	}
		
}
