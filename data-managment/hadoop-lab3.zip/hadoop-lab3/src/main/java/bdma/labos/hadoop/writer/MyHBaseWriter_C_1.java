package bdma.labos.hadoop.writer;

public class MyHBaseWriter_C_1 extends MyHBaseWriter {

	protected String toFamily(String attribute) {
		return null;
	}
		
}
