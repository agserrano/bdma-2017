package exercise_4;

import java.util.ArrayList;

import com.clearspring.analytics.util.Lists;
import com.google.common.hash.Hashing;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.MetadataBuilder;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import scala.collection.Seq;
import scala.runtime.AbstractFunction2;
import scala.xml.Node;
import utils.UtilsXML;
import scala.Tuple2;
import org.graphframes.*;

public class Exercise_4 {

    public static void wikipedia(JavaSparkContext jsc, SQLContext sqlctx) {



    }
}















