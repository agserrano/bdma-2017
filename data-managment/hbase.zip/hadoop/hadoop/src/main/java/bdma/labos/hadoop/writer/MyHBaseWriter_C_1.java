package bdma.labos.hadoop.writer;

import java.util.HashMap;

public class MyHBaseWriter_C_1 extends MyHBaseWriter {

	protected String toFamily(String attribute) {
		return null;
	}
		
}
