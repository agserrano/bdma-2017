package exercise2;

public class Exercise_2_model_2 {

	public static void dataGenerator(int N) {
		
	}
}
