package exercise2;

public class Exercise_2_model_1 {

	public static void dataGenerator(int N) {
		
	}
}
